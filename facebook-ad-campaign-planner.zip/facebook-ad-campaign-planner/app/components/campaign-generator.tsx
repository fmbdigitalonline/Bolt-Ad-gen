'use client'

import { useState } from 'react'
import { IdeationPhase } from './phases/ideation-phase'
import { MarketingMaterialsPhase } from './phases/marketing-materials-phase'
import { VisualAdCreationPhase } from './phases/visual-ad-creation-phase'
import { CampaignSummary } from './phases/campaign-summary'

const phases = [
  { id: 'ideation', name: 'Ideation', component: IdeationPhase },
  { id: 'marketingMaterials', name: 'Marketing Materials', component: MarketingMaterialsPhase },
  { id: 'visualAdCreation', name: 'Visual Ad Creation', component: VisualAdCreationPhase },
  { id: 'summary', name: 'Campaign Summary', component: CampaignSummary },
]

export function CampaignGenerator() {
  const [currentPhase, setCurrentPhase] = useState(0)
  const [campaignData, setCampaignData] = useState({})

  const CurrentPhaseComponent = phases[currentPhase].component

  const handleNextPhase = (data: any) => {
    setCampaignData((prevData) => ({ ...prevData, ...data }))
    if (currentPhase < phases.length - 1) {
      setCurrentPhase(currentPhase + 1)
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between mb-4">
        {phases.map((phase, index) => (
          <div
            key={phase.id}
            className={`px-4 py-2 rounded ${
              index === currentPhase ? 'bg-primary text-primary-foreground' : 'bg-secondary'
            }`}
          >
            {phase.name}
          </div>
        ))}
      </div>
      <CurrentPhaseComponent onComplete={handleNextPhase} data={campaignData} />
    </div>
  )
}

