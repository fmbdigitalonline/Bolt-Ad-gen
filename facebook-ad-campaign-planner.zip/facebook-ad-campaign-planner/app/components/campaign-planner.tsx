'use client'

import { useState } from 'react'
import { Ideation } from './phases/ideation'
import { AdContent } from './phases/ad-content'
import { Design } from './phases/design'
import { CampaignSetup } from './phases/campaign-setup'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'

const phases = [
  { id: 'ideation', name: 'Ideation', component: Ideation },
  { id: 'adContent', name: 'Ad Content', component: AdContent },
  { id: 'design', name: 'Design', component: Design },
  { id: 'campaignSetup', name: 'Campaign Setup', component: CampaignSetup },
]

export function CampaignPlanner() {
  const [currentPhase, setCurrentPhase] = useState(0)
  const [campaignData, setCampaignData] = useState({})

  const CurrentPhaseComponent = phases[currentPhase].component

  const handleNextPhase = (data: any) => {
    setCampaignData((prevData) => ({ ...prevData, ...data }))
    if (currentPhase < phases.length - 1) {
      setCurrentPhase(currentPhase + 1)
    }
  }

  const handlePreviousPhase = () => {
    if (currentPhase > 0) {
      setCurrentPhase(currentPhase - 1)
    }
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Campaign Planner</CardTitle>
        <CardDescription>Create your Facebook ad campaign in 4 easy steps</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="mb-4 flex justify-between">
          {phases.map((phase, index) => (
            <Button
              key={phase.id}
              variant={index === currentPhase ? "default" : "outline"}
              className="w-1/4"
              onClick={() => setCurrentPhase(index)}
              disabled={index > currentPhase}
            >
              {phase.name}
            </Button>
          ))}
        </div>
        <CurrentPhaseComponent onComplete={handleNextPhase} data={campaignData} />
        <div className="mt-4 flex justify-between">
          <Button onClick={handlePreviousPhase} disabled={currentPhase === 0}>
            Previous
          </Button>
          <Button onClick={() => handleNextPhase({})} disabled={currentPhase === phases.length - 1}>
            Next
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

