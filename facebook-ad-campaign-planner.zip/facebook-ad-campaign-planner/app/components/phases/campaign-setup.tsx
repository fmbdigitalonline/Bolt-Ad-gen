import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'

export function CampaignSetup({ onComplete, data }) {
  const handleFinish = () => {
    onComplete(data)
    // Here you would typically trigger the actual campaign creation on Facebook
    alert('Campaign created successfully!')
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Campaign Setup</CardTitle>
        <CardDescription>Review your campaign configuration</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <h3 className="font-bold mb-2">Campaign Name</h3>
          <p>{data.campaignName}</p>
        </div>
        <div>
          <h3 className="font-bold mb-2">Campaign Objective</h3>
          <p>{data.campaignObjective}</p>
        </div>
        <div>
          <h3 className="font-bold mb-2">Budget</h3>
          <p>${data.budget} per day</p>
        </div>
        <div>
          <h3 className="font-bold mb-2">Schedule</h3>
          <p>Start: {data.startDate}</p>
          <p>End: {data.endDate}</p>
        </div>
        <Button onClick={handleFinish}>Create Campaign</Button>
      </CardContent>
    </Card>
  )
}

