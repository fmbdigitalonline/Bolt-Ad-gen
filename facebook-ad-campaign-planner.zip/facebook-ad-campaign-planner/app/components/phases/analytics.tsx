import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'

export function Analytics({ data }) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Campaign Summary</CardTitle>
        <CardDescription>Review your campaign details</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <h3 className="font-bold">Business Idea</h3>
          <p>{data.businessIdea}</p>
        </div>
        <div>
          <h3 className="font-bold">Key Audiences</h3>
          <p>{data.keyAudiences}</p>
        </div>
        <div>
          <h3 className="font-bold">Product Description</h3>
          <p>{data.productDescription}</p>
        </div>
        <div>
          <h3 className="font-bold">Ad Content</h3>
          <ul>
            <li>Angles: {data.angles?.join(', ')}</li>
            <li>Hooks: {data.hooks?.join(', ')}</li>
            <li>Ad Copies: {data.adCopies?.join(', ')}</li>
            <li>CTAs: {data.ctas?.join(', ')}</li>
          </ul>
        </div>
        <div>
          <h3 className="font-bold">Design</h3>
          <p>Style Preferences: {data.stylePreferences}</p>
          <p>Ad Creatives: {data.adCreatives?.join(', ')}</p>
        </div>
        <div>
          <h3 className="font-bold">Campaign Setup</h3>
          <p>Name: {data.campaignName}</p>
          <p>Objective: {data.campaignObjective}</p>
          <p>Budget: {data.budget}</p>
          <p>Schedule: {data.schedule}</p>
        </div>
        <Button>Finish and Deploy Campaign</Button>
      </CardContent>
    </Card>
  )
}

