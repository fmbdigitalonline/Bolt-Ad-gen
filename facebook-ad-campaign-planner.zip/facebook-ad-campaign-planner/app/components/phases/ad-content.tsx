import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'

export function AdContent({ onComplete, data }) {
  const handleContinue = () => {
    onComplete(data)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Ad Content</CardTitle>
        <CardDescription>Review generated marketing angles, hooks, ad copies, and CTAs</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {['angles', 'hooks', 'adCopies', 'ctas'].map((contentType) => (
          <div key={contentType}>
            <h3 className="font-bold mb-2 capitalize">{contentType}</h3>
            <ul className="list-disc pl-5">
              {data[contentType].map((item, index) => (
                <li key={index}>{item}</li>
              ))}
            </ul>
          </div>
        ))}
        <Button onClick={handleContinue}>Continue</Button>
      </CardContent>
    </Card>
  )
}

