'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { generateCampaignData } from '@/lib/generate-campaign-data'

export function Ideation({ onComplete }) {
  const [businessIdea, setBusinessIdea] = useState('')
  const [keyAudiences, setKeyAudiences] = useState('')

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const campaignData = await generateCampaignData({ businessIdea, keyAudiences })
    onComplete(campaignData)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>Ideation</CardTitle>
          <CardDescription>Define your business idea and target audience</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label htmlFor="businessIdea" className="block mb-2 font-bold">
              Business Idea
            </label>
            <Textarea
              id="businessIdea"
              value={businessIdea}
              onChange={(e) => setBusinessIdea(e.target.value)}
              placeholder="Describe your business idea"
              required
            />
          </div>
          <div>
            <label htmlFor="keyAudiences" className="block mb-2 font-bold">
              Key Audiences
            </label>
            <Textarea
              id="keyAudiences"
              value={keyAudiences}
              onChange={(e) => setKeyAudiences(e.target.value)}
              placeholder="List your key target audiences"
              required
            />
          </div>
        </CardContent>
      </Card>
      <Button type="submit">Generate Campaign</Button>
    </form>
  )
}

