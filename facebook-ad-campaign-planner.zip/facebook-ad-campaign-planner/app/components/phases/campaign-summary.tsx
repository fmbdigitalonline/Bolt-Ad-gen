import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'

export function CampaignSummary({ data }) {
  const handleLaunchCampaign = () => {
    // In a real application, this would trigger the Facebook API to create the campaign
    alert('Campaign launched successfully!')
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Campaign Summary</CardTitle>
        <CardDescription>Review your campaign details before launch</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div>
            <h3 className="font-bold">Product Information</h3>
            <p>Name: {data.productName}</p>
            <p>Description: {data.productDescription}</p>
            <p>Target Goals: {data.targetGoals}</p>
          </div>
          <div>
            <h3 className="font-bold">Selected Audience</h3>
            <p>{data.selectedAudience}</p>
          </div>
          <div>
            <h3 className="font-bold">Marketing Materials</h3>
            {/* Display selected marketing materials */}
          </div>
          <div>
            <h3 className="font-bold">Visual Ads</h3>
            {/* Display selected visual ads */}
          </div>
          <Button onClick={handleLaunchCampaign}>Launch Campaign</Button>
        </div>
      </CardContent>
    </Card>
  )
}

