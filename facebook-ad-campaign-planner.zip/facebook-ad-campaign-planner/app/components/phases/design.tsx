import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import Image from 'next/image'

export function Design({ onComplete, data }) {
  const handleContinue = () => {
    onComplete(data)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Design</CardTitle>
        <CardDescription>Review generated ad creatives</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          {data.adCreatives.map((creative, index) => (
            <div key={index} className="border p-2 rounded">
              <Image
                src={creative}
                alt={`Ad Creative ${index + 1}`}
                width={300}
                height={300}
                className="w-full h-auto"
              />
            </div>
          ))}
        </div>
        <Button onClick={handleContinue}>Continue</Button>
      </CardContent>
    </Card>
  )
}

