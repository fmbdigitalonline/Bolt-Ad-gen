'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { generateAudienceProfiles } from '@/lib/ai-simulation'

export function IdeationPhase({ onComplete }) {
  const [productName, setProductName] = useState('')
  const [productDescription, setProductDescription] = useState('')
  const [targetGoals, setTargetGoals] = useState('')
  const [audienceProfiles, setAudienceProfiles] = useState([])
  const [selectedAudience, setSelectedAudience] = useState(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const profiles = await generateAudienceProfiles({ productName, productDescription, targetGoals })
    setAudienceProfiles(profiles)
  }

  const handleAudienceSelection = (audience) => {
    setSelectedAudience(audience)
  }

  const handleComplete = () => {
    onComplete({ productName, productDescription, targetGoals, selectedAudience })
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Ideation Phase</CardTitle>
        <CardDescription>Provide initial product information</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="productName" className="block text-sm font-medium text-gray-700">
              Product Name
            </label>
            <Input
              id="productName"
              value={productName}
              onChange={(e) => setProductName(e.target.value)}
              required
            />
          </div>
          <div>
            <label htmlFor="productDescription" className="block text-sm font-medium text-gray-700">
              Product Description
            </label>
            <Textarea
              id="productDescription"
              value={productDescription}
              onChange={(e) => setProductDescription(e.target.value)}
              required
            />
          </div>
          <div>
            <label htmlFor="targetGoals" className="block text-sm font-medium text-gray-700">
              Target Goals
            </label>
            <Input
              id="targetGoals"
              value={targetGoals}
              onChange={(e) => setTargetGoals(e.target.value)}
              required
            />
          </div>
          <Button type="submit">Generate Audience Profiles</Button>
        </form>

        {audienceProfiles.length > 0 && (
          <div className="mt-6">
            <h3 className="text-lg font-semibold mb-2">Select Target Audience</h3>
            <div className="space-y-2">
              {audienceProfiles.map((audience, index) => (
                <div key={index} className="flex items-center space-x-2">
                  <input
                    type="radio"
                    id={`audience-${index}`}
                    name="audience"
                    value={index}
                    checked={selectedAudience === audience}
                    onChange={() => handleAudienceSelection(audience)}
                  />
                  <label htmlFor={`audience-${index}`}>{audience}</label>
                </div>
              ))}
            </div>
            <div className="mt-4 space-x-2">
              <Button onClick={handleComplete} disabled={!selectedAudience}>
                Use this audience
              </Button>
              <Button variant="outline" onClick={handleSubmit}>
                Regenerate suggestions
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

