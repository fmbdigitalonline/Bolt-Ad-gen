'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { generateMarketingMaterials } from '@/lib/ai-simulation'

export function MarketingMaterialsPhase({ onComplete, data }) {
  const [marketingMaterials, setMarketingMaterials] = useState(null)

  useEffect(() => {
    generateMarketingMaterials(data).then(setMarketingMaterials)
  }, [data])

  const handleComplete = () => {
    onComplete({ marketingMaterials })
  }

  if (!marketingMaterials) {
    return <div>Generating marketing materials...</div>
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Marketing Materials</CardTitle>
        <CardDescription>Review and select marketing materials</CardDescription>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Type</TableHead>
              <TableHead>Content</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {Object.entries(marketingMaterials).map(([type, items]) => (
              items.map((item, index) => (
                <TableRow key={`${type}-${index}`}>
                  <TableCell>{type}</TableCell>
                  <TableCell>{item}</TableCell>
                  <TableCell>
                    <Button variant="outline" size="sm">Use</Button>
                    <Button variant="outline" size="sm">Regenerate</Button>
                    <Button variant="outline" size="sm">Save</Button>
                  </TableCell>
                </TableRow>
              ))
            ))}
          </TableBody>
        </Table>
        <div className="mt-4 space-x-2">
          <Button onClick={handleComplete}>Proceed to Visual Ad Creation</Button>
          <Button variant="outline">Download Materials</Button>
        </div>
      </CardContent>
    </Card>
  )
}

