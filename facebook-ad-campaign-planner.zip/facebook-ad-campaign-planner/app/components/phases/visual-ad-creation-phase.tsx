'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { generateVisualAds } from '@/lib/ai-simulation'

export function VisualAdCreationPhase({ onComplete, data }) {
  const [visualAds, setVisualAds] = useState([])

  useEffect(() => {
    generateVisualAds(data).then(setVisualAds)
  }, [data])

  const handleComplete = () => {
    onComplete({ visualAds })
  }

  if (visualAds.length === 0) {
    return <div>Generating visual ads...</div>
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Visual Ad Creation</CardTitle>
        <CardDescription>Review and select visual ads</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-4">
          {visualAds.map((ad, index) => (
            <div key={index} className="border p-4 rounded">
              <img src={ad.imageUrl} alt={`Visual Ad ${index + 1}`} className="w-full h-auto mb-2" />
              <div className="space-x-2">
                <Button variant="outline" size="sm">Use</Button>
                <Button variant="outline" size="sm">Regenerate</Button>
                <Button variant="outline" size="sm">Download</Button>
              </div>
            </div>
          ))}
        </div>
        <div className="mt-4">
          <Button onClick={handleComplete}>Finalize Campaign</Button>
        </div>
      </CardContent>
    </Card>
  )
}

