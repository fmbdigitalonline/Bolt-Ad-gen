export async function generateAudienceProfiles(data) {
  // Simulate API call delay
  await new Promise(resolve => setTimeout(resolve, 1000))

  // Generate mock audience profiles
  return [
    "Young professionals aged 25-35 interested in tech gadgets",
    "Parents aged 30-45 looking for educational toys",
    "Fitness enthusiasts aged 20-40 seeking workout equipment"
  ]
}

export async function generateMarketingMaterials(data) {
  // Simulate API call delay
  await new Promise(resolve => setTimeout(resolve, 2000))

  // Generate mock marketing materials
  return {
    angles: Array(10).fill(null).map((_, i) => `Marketing Angle ${i + 1}`),
    hooks: Array(10).fill(null).map((_, i) => `Hook ${i + 1}`),
    adCopies: Array(5).fill(null).map((_, i) => `Ad Copy ${i + 1}`),
    ctas: Array(5).fill(null).map((_, i) => `CTA ${i + 1}`)
  }
}

export async function generateVisualAds(data) {
  // Simulate API call delay
  await new Promise(resolve => setTimeout(resolve, 2000))

  // Generate mock visual ads
  return Array(10).fill(null).map((_, i) => ({
    imageUrl: `/placeholder.svg?text=Visual+Ad+${i + 1}`,
    hook: `Hook for Visual Ad ${i + 1}`
  }))
}

