export async function generateCampaignData({ businessIdea, keyAudiences }) {
  // Simulate API call delay
  await new Promise(resolve => setTimeout(resolve, 2000))

  // Generate mock data
  const angles = Array(10).fill(null).map((_, i) => `Angle ${i + 1} for ${businessIdea}`)
  const hooks = Array(10).fill(null).map((_, i) => `Hook ${i + 1} for ${keyAudiences}`)
  const adCopies = Array(10).fill(null).map((_, i) => `Ad Copy ${i + 1}: ${businessIdea} for ${keyAudiences}`)
  const ctas = Array(10).fill(null).map((_, i) => `CTA ${i + 1}: Try ${businessIdea} now!`)
  const adCreatives = Array(10).fill(null).map((_, i) => `/placeholder.svg?text=Ad+Creative+${i + 1}`)

  return {
    angles,
    hooks,
    adCopies,
    ctas,
    adCreatives,
    campaignName: `${businessIdea} Campaign`,
    campaignObjective: 'Conversions',
    budget: 50,
    startDate: new Date().toISOString().split('T')[0],
    endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
  }
}

